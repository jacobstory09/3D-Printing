Bambu Studio import
-------------------
1. File → Import → terrain_ams.obj (or drag this ZIP's OBJ onto the plate).
2. If asked to load as one object with multiple parts, choose Yes.
3. In the Objects panel, assign each part/material to the closest AMS filament.
4. See palette.json for recommended color names and hex values.
